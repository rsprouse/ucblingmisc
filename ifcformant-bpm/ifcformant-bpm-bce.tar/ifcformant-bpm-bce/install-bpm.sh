#!/usr/bin/env sh

# Install ifcformant into BPM.

mv ifcformant.so /usr/local/lib/python2.7/dist-packages
if [ $? != 0 ]; then
    exit 1
fi
mv ifcformant /usr/local/bin
if [ $? != 0 ]; then
    exit 2
fi
