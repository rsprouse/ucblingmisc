#!/usr/bin/env sh

# Install ifcformant into BPM.

mv ifcformant.so /usr/local/lib/python2.7/dist-packages
mv ifcformant /usr/local/bin
