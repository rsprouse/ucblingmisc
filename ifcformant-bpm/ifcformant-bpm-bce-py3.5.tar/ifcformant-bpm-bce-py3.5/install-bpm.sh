#!/usr/bin/env sh

# Install ifcformant into BPM under Python 3.5

mv ifcformant.cpython-35m-x86_64-linux-gnu.so /home/ubuntu/miniconda3/lib/python3.5/site-packages/
if [ $? != 0 ]; then
    exit 1
fi
mv ifcformant /usr/local/bin
if [ $? != 0 ]; then
    exit 2
fi
